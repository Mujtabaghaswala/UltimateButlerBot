import os, time, json, shutil, subprocess, re, sys

def get_vram_mb():
    try:
        out = subprocess.check_output(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"], stderr=subprocess.DEVNULL).decode().strip()
        vals = [int(x) for x in out.splitlines() if x.strip()]
        return max(vals) if vals else 0
    except Exception:
        return 0

def get_ram_mb():
    try:
        with open('/proc/meminfo') as f:
            mem = f.read()
        m = re.search(r'MemAvailable:\s+(\d+) kB', mem)
        if not m: return 0
        # Crude: we'll estimate peak as total - available at sample time (placeholder)
        t = re.search(r'MemTotal:\s+(\d+) kB', mem)
        total = int(t.group(1)) if t else 0
        avail = int(m.group(1))
        used_kb = total - avail
        return used_kb // 1024
    except Exception:
        return 0

def du_bytes(path):
    total = 0
    for base, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(base, f))
            except FileNotFoundError:
                pass
    return total

def images_bytes():
    try:
        out = subprocess.check_output(["docker","image","ls","--format","{{.Repository}}:{{.Tag}} {{.Size}}"]).decode()
        total = 0
        for line in out.splitlines():
            size = line.split()[-1]
            m = re.match(r'([0-9.]+)(GB|MB|KB)', size, re.I)
            if not m: continue
            val, unit = float(m.group(1)), m.group(2).upper()
            mult = 1
            if unit == 'GB': mult = 1024**2
            elif unit == 'MB': mult = 1024**1
            elif unit == 'KB': mult = 1
            total += int(val * mult) * 1024  # rough
        return total
    except Exception:
        return 0

def main():
    start = time.time()
    # Cold-start timing is measured outside in harness normally; here we just report snapshot
    ram = get_ram_mb()
    vram = get_vram_mb()
    models = du_bytes(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "models")).replace("/harness",""))
    imgs = images_bytes()
    report = {
        "ram_mb_estimate": ram,
        "vram_mb_peak": vram,
        "working_set_mb_estimate": ram + vram,
        "models_bytes": models,
        "images_bytes_estimate": imgs
    }
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
