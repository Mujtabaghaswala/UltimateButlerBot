#!/usr/bin/env bash
set -euo pipefail

echo "[1/4] Checking health endpoints..."
for svc in smk toolsmith evaluator deployer inference calendar-api email-api paper-broker; do
  curl -sf http://localhost:$(docker inspect -f '{{range .NetworkSettings.Ports}}{{(index . 0).HostPort}}{{end}}' $svc)/healthz >/dev/null
done
echo "Health OK"

echo "[2/4] Running stub tests (placeholders)..."
python3 harness/tests_policy.py
python3 harness/tests_rag.py
python3 harness/tests_autoupgrade.py
python3 harness/tests_kill_rollback.py

echo "[3/4] Measuring efficiency footprint metrics..."
python3 harness/metrics_efficiency.py || true

echo "[4/4] Done."
