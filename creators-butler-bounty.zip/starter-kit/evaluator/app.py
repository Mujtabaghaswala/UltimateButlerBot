from fastapi import FastAPI, Request
app = FastAPI()

@app.get("/healthz")
def healthz(): return {"status":"ok","service":"evaluator"}


