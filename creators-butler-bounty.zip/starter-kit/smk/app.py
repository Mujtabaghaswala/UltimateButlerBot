from fastapi import FastAPI, Request
app = FastAPI()

@app.get("/healthz")
def healthz(): return {"status":"ok","service":"smk"}


from pydantic import BaseModel
class ChatReq(BaseModel):
    message: str

@app.post("/v1/chat")
def chat(req: ChatReq):
    # TODO: implement policy-aware tool routing
    return {"reply": "SMK stub: received", "echo": req.message}

@app.get("/v1/daily_brief")
def daily_brief():
    return {"schedule": [], "tasks": [], "incidents": [], "proposed_upgrades": []}

@app.post("/v1/control/kill")
def kill():
    # TODO: implement safe halt
    return {"ok": True, "message": "Kill acknowledged (stub)"}

