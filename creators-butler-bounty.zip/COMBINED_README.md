# Creators Butler Bounty — Combined Package

This repository bundle includes:
- **docs/** – Full bounty brief + judging + anti-gaming
- **starter-kit/** – Docker compose, mocks, seeds, sample policy, harness outline
- **outreach-kit/** – Ready-to-post copy, UTM guide, and schedule CSV
- **automation/** & **.github/workflows/** – Social posting scripts (Twitter/X, LinkedIn), CLI helpers, and a GitHub Action workflow
- **AUTOMATION_README.md** – Setup for tokens/secrets and usage

Quick start:
```bash
cd starter-kit
make up
make demo
```

Outreach:
- Edit `outreach-kit/posts/*` to fill `<REPO_URL>`, `<DEADLINE>`, `<PRIZE_TOTAL>`
- Run `python automation/generate_calendar.py outreach-kit/schedule.csv outreach_schedule.ics`
- Use GitHub Actions → **Post Socials** to push to X/LinkedIn (after adding secrets)
