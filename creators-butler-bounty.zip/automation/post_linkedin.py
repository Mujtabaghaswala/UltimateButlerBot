import os, sys, json, requests
msg = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("MESSAGE","")
if not msg:
    print("No message provided; skipping LinkedIn.")
    raise SystemExit(0)

token = os.environ.get("LINKEDIN_ACCESS_TOKEN")
member = os.environ.get("LINKEDIN_MEMBER_URN")
org = os.environ.get("LINKEDIN_ORG_URN")
if not token or (not member and not org):
    print("LinkedIn token/URN missing; skipping.")
    raise SystemExit(0)

author = org if org else member
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}
payload = {
  "author": author,
  "lifecycleState": "PUBLISHED",
  "specificContent": {
    "com.linkedin.ugc.ShareContent": {
      "shareCommentary": {"text": msg[:1300]},
      "shareMediaCategory": "NONE"
    }
  },
  "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
}
url = "https://api.linkedin.com/v2/ugcPosts"
try:
    r = requests.post(url, headers=headers, json=payload, timeout=20)
    print("LinkedIn status:", r.status_code, r.text[:200])
except Exception as e:
    print("LinkedIn post error:", e)
