import os, sys
msg = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("MESSAGE","")
if not msg:
    print("No message provided; skipping Twitter.")
    sys.exit(0)

api_key = os.environ.get("TWITTER_API_KEY")
api_secret = os.environ.get("TWITTER_API_SECRET")
access_token = os.environ.get("TWITTER_ACCESS_TOKEN")
access_secret = os.environ.get("TWITTER_ACCESS_SECRET")
if not all([api_key, api_secret, access_token, access_secret]):
    print("Twitter secrets missing; skipping.")
    sys.exit(0)

try:
    import tweepy
    auth = tweepy.OAuth1UserHandler(api_key, api_secret, access_token, access_secret)
    api = tweepy.API(auth)
    api.update_status(status=msg[:280])
    print("Tweet posted.")
except Exception as e:
    print("Twitter post error:", e)
    sys.exit(0)
