import argparse, webbrowser, urllib.parse

parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True, help="Repo URL (with or without UTM)")
parser.add_argument("--deadline", required=True)
parser.add_argument("--prize", required=True)
args = parser.parse_args()

repo = args.repo
deadline = args.deadline
prize = args.prize

copy = f"""Sealed‑Kernel AI that codes its own tools (local‑first bounty, {prize}).
Starter kit + harness: {repo}
Deadline: {deadline}
Permissive licenses; synthetic data; efficiency scoring (RAM+VRAM, disk, cold‑start)."""

targets = {
  "Devpost": "https://devpost.com/software/new",
  "Gitcoin": "https://gitcoin.co/bounties/new",
  "Hacker News (Show)": "https://news.ycombinator.com/submit",
  "Reddit r/MachineLearning": "https://www.reddit.com/r/MachineLearning/submit",
  "Reddit r/LocalLLaMA": "https://www.reddit.com/r/LocalLLaMA/submit",
  "LinkedIn": "https://www.linkedin.com/feed/",
  "Twitter/X": "https://twitter.com/intent/tweet?text=" + urllib.parse.quote(copy)
}

for name, url in targets.items():
    print(f"Opening: {name}")
    webbrowser.open_new_tab(url)

print("\nSuggested copy:\n")
print(copy)
