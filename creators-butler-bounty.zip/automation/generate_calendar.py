import csv, sys, datetime

def main(csv_path, outfile):
    tz = 'America/Chicago'
    def ics_event(dt, title, desc):
        dtstamp = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
        dtstart = dt.strftime('%Y%m%dT%H%M%S')
        uid = f"{dtstart}-{hash(title) & 0xffffffff}@creators"
        return f"""BEGIN:VEVENT
DTSTAMP:{dtstamp}
UID:{uid}
DTSTART;TZID=America/Chicago:{dtstart}
SUMMARY:{title}
DESCRIPTION:{desc}
DURATION:PT30M
END:VEVENT
"""
    with open(csv_path, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    body = ["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Creators//Outreach//EN","CALSCALE:GREGORIAN","METHOD:PUBLISH"]
    for r in rows:
        date = r['date'].strip()
        time_ct = r['time_ct'].strip()
        title = f"[{r['purpose']}] {r['channel']} post"
        desc = f"Post to {r['channel']} using {r['post_file']}"
        dt = datetime.datetime.strptime(f"{date} {time_ct}", "%Y-%m-%d %H:%M")
        body.append(ics_event(dt, title, desc))
    body.append("END:VCALENDAR")
    with open(outfile, "w", encoding="utf-8") as f:
        f.write("\n".join(body))

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python automation/generate_calendar.py schedule.csv outreach_schedule.ics")
        raise SystemExit(2)
    main(sys.argv[1], sys.argv[2])
