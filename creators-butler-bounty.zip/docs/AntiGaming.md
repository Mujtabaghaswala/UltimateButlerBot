# Anti-gaming Notes
- Efficiency points are contingent on meeting all gates and the RAG latency SLO.
- All model weights must be stored in `/models`.
- No scraping, no live trading, no hidden network calls beyond allowlist.
- Deterministic seeds; reproducible builds preferred.
