# Judging Procedure

1) Provision fresh VM; clone team repo; `cd starter-kit`.
2) `make up` → wait for `/healthz` from all services.
3) `make demo` → capture logs, artifacts, daily brief.
4) Run black-box harness tests.
5) Measure Efficiency & Footprint metrics.
6) Score via rubric; fail on any disqualifier.
7) Re-run finalists with GPU to verify autoupgrade; short technical interview.
