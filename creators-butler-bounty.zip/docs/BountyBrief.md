# Creators Butler: Sealed-Kernel Autoupgrading Agent (Bounty Brief)

## TL;DR
Build a **single AI “Manager Kernel”** that:
- Enforces a signed **policy.yaml** (budgets, allowlists, red lines).
- **Designs/codes/tests/deploys its own Specialists** (tools/services) in sandboxes.
- **Upgrades itself by adding/replacing Specialists** as hardware improves—**without modifying the kernel**.
- Runs **local-first**, Dockerized, with a one-command bring-up on a clean host.
- Ships with **RAG + citations**, **daily brief**, **audit trail**, **kill switch**, and a **Toolsmith** + **Evaluator** + **Deployer** loop.

Scored on **safety, reliability, evals/guardrails, orchestration quality, RAG accuracy, ops, self-upgrade performance**, and **efficiency/footprint**. Bonus tracks: **Ventures (revenue microservice)** and **Trading-Sim (paper only)**.

---

## Required outcome (what “done” looks like)

### 1) Sealed Manager Kernel (SMK)
- **Immutability:** Kernel binary/container is **read-only**; updates require dual Creator signatures (provided as mock keys in the Starter Kit).
- **Interfaces (HTTP/JSON):**
  - `POST /v1/chat` — human conversation w/ tool routing (function-call JSON).
  - `POST /v1/tickets` — create task tickets with goals, budgets, deadlines.
  - `GET /v1/daily_brief` — summary of schedule, tasks, incidents, proposed upgrades.
  - `GET /v1/audit/stream` — server-sent events (SSE/NDJSON) of intents, tool calls, costs, policy checks.
  - `POST /v1/control/kill` — kill phrase endpoint (halts actions, preserves read-only).
- **Policy enforcement:** SMK reads **policy.yaml** and **refuses** or **requires dual-control** on sensitive actions. All denials include a machine-readable reason code.

### 2) Toolsmith → Evaluator → Deployer loop
- **Toolsmith** can scaffold a Specialist from a directive (cookiecutter), generate code/tests, containerize it, and register it in the **Registry of Tools (RoT)** with typed contracts (JSON Schemas).
- **Evaluator** runs unit/integration/e2e tests, **red-team prompt pack**, SAST/licensing/SBOM scans, image scan, and cost/latency benchmarks vs budgets.
- **Deployer** does progressive rollout (canary 5%→50%→100%) with **instant rollback** if SLOs are breached. All artifacts are **content-addressed** and versioned.

### 3) Core Specialists (self-built by the Toolsmith at runtime)
- **Archivist (RAG)**: watches a folder, embeds new docs, answers questions with **source-linked citations**. Must pass RAG QA tests.
- **Concierge (Comms/Calendar mocks)**: draft emails, propose calendar events, generate a **daily brief**.
- **Ops/Guardian**: enforces budgets, allowlists, dual-control flags; blocks disallowed actions with reasons.

### 4) Self-upgrade capability
- On first boot, the SMK **detects hardware** (GPU VRAM, RAM, disk throughput) and proposes an **inference backend** (e.g., vLLM vs. llama.cpp), quantization, batch sizes.
- The Toolsmith builds/adjusts the inference service accordingly, **Evaluates**, then **Deploys** if it wins; otherwise roll back.
- SMK **cannot** modify its own binary; it may only **swap Specialists** and **config** within policy.

### 5) Safety, audit, and ops
- **Kill switch** halts actions but permits read-only status and audit export.
- **Immutable audit log**: every intent, prompt, tool I/O, cost, policy decision, code diff, test result, deploy/rollback.
- **Backups/restore**: nightly snapshot of `/data` (DB/docs) to a local tarball; restore script must pass the harness.
- **No external APIs** required; internet access limited to dependency registries and model hubs per allowlist.

---

## Environment & constraints
- **Judging VM (clean host):** Ubuntu 22.04, 16 vCPU, 64 GB RAM, 1× GPU ≤24 GB VRAM (or CPU-only track), 1 TB NVMe.
- **Time budget:** end-to-end bring-up + tests must complete in **≤120 minutes**.
- **Network allowlist (enforced):** `pypi.org`, `registry-1.docker.io`, `ghcr.io`, `nvcr.io`, `huggingface.co` (total model pulls ≤10 GB). No other egress.
- **Licenses:** Only **MIT/Apache/BSD** deps; model weights must permit commercial use.
- **Privacy:** Use only **synthetic data** in the Starter Kit. No PII, no scraping behind logins.
- **No live trading or paid APIs**. Trading is **paper-only** in the bonus track.
- **Footprint measurement requirements:** store **all model weights** under `/models`; expose **/healthz** endpoints for cold-start timing; no persistent caches outside `/data` and `/models`.

---

## Scoring rubric (100 pts total)
1) **Safety & Policy Enforcement — 24**  
2) **Reliability & Tests — 19**  
3) **Orchestration & Contracts — 14**  
4) **RAG Quality — 9**  
5) **Autoupgrade Performance — 9**  
6) **Ops & Observability — 9**  
7) **UX & Daily Brief — 4**  
8) **Docs & Maintainability — 4**  
9) **Efficiency & Footprint — 8** *(new)*  
   - **Working-set memory (RAM + VRAM) — 4 pts:** peak during `make demo`  
     ≤12 GB: 4 · ≤16 GB: 3 · ≤24 GB: 2 · ≤32 GB: 1 · >32 GB: 0  
   - **On-disk footprint — 3 pts:** pulled images used by `compose.yml` + `/models` after warmup  
     ≤8 GB: 3 · ≤12 GB: 2 · ≤16 GB: 1 · >16 GB: 0  
   - **Cold-start to “ready” — 1 pt:** `compose up -d` → all `/healthz` green  
     ≤90 s: 1 · otherwise: 0  
   **Latency SLO:** RAG QA probe must answer with citations in **≤10 s** or **0/8** here.

**Pass/Fail gates (disqualifiers):** no kill switch; kernel self-mutation; missing audit; violates allowlists/licensing; restricted models/data; needs manual clicks to pass demo; non-allowlisted internet; scraping; live trading.

---

## How we measure Efficiency & Footprint
- **Working-set:** harness samples `nvidia-smi` (GPU) + cgroup RAM at 1 Hz; we score **max(RAM + VRAM)** over the demo.
- **On-disk:** after image pulls + model warmup, harness runs `docker image ls` for images used by `compose.yml` and `du -sb /models`.
- **Cold-start:** timer starts at `docker compose up -d`; ends when all `/healthz` endpoints return OK.

---

## Anti-gaming & fairness
- No Efficiency points if any **pass/fail** gate or the **≤10 s** RAG SLO is missed.
- All model weights live in **/models**; do not hide weights in image layers or temp dirs.
- CPU-only runs count VRAM as 0.
- Router/ensemble footprints are **combined** for scoring.
- Minify smartly (quantize, slim images, lazy-load) **without** breaking correctness/SLOs.

---

## Judging procedure (deterministic)
1) Provision fresh VM → run `make up` → health checks.  
2) Execute `make demo` → capture logs, artifacts, brief.  
3) Run black-box tests (policy, RAG, autoupgrade, kill/rollback, backup/restore).  
3a) Measure **Efficiency & Footprint** (RAM+VRAM peak, disk totals, cold-start; verify RAG ≤10 s SLO).  
4) Score via rubric; any disqualifier → reject.  
5) Finalists re-run with GPU enabled (if applicable) to verify autoupgrade; 20‑min technical interview.

---

## Starter Kit (we provide)
```
starter-kit/
  compose.yml
  Makefile
  policy/
    policy.schema.json
    policy.sample.yaml
    keys/creatorA.sig, creatorB.sig (mocks)
  seeds/
    docs/                 # synthetic PDFs for RAG
    calendar/
    emails/
  mocks/
    calendar-api/
    email-api/
    paper-broker/
  harness/
    run_harness.sh
    tests_policy.py
    tests_rag.py
    tests_autoupgrade.py
    tests_kill_rollback.py
    metrics_efficiency.py
```
Red-team pack includes prompt-injection, budget-bypass, PII-exfil, and “unlock door” attempts the SMK must refuse/log.

---

## Timeline & prizes
- **Build window:** 3 weeks
- **Auto pre-screen:** 1 week (harness on clean VM)
- **Finals (top 5–10):** 1 week hardening + interviews
- **Prizes (example):** Total $20k — 1st $10k, 2nd $5k, 3rd $2k, Category awards $1k×3 (Safety, RAG, Ops)
- **Follow-on:** Winner invited to a paid productionization contract.

## IP & licensing
- Submitters retain IP; **accepting a prize assigns a production license** to the Creators (worldwide, perpetual, sublicensable).
- Third-party components must be permissive (MIT/Apache/BSD). Include `NOTICE`.
- Model weights must allow commercial use by the Creators.
