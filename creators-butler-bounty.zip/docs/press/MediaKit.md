# Media Kit (Winner Announcement)

Assets you can share with posts and articles:

- **Repo link:** <REPO_URL>
- **Winner repo:** <WINNER_REPO_URL>
- **Screenshots:** add PNGs to this folder: `docs/press/screenshots/`
- **30–60s demo video:** add MP4: `docs/press/demo.mp4`
- **Social preview image:** set in GitHub → Settings → Social Preview (1200x630 recommended)

**Hashtags (optional):** #AI #Agents #LocalLLM #MLOps #RAG #Security #OpenSource
