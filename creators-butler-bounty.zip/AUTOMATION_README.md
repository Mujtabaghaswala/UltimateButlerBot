# Automation Add‑ons

Drop these files into your repo:
- `.github/workflows/post_socials.yml` — GitHub Action to post to Twitter/X and LinkedIn via secrets.
- `automation/post_twitter.py` — posts a tweet using Tweepy (needs API keys with write perms).
- `automation/post_linkedin.py` — posts a LinkedIn share using a user or organization access token.
- `automation/open_submission_pages.py` — opens browser tabs with prefilled copy for Devpost, Gitcoin, HN, Reddit, etc.
- `automation/generate_calendar.py` — builds `outreach_schedule.ics` from `outreach-kit/schedule.csv`.

## Secrets to add in GitHub (Settings → Secrets and variables → Actions)
**Twitter/X**
- `TWITTER_API_KEY`
- `TWITTER_API_SECRET`
- `TWITTER_ACCESS_TOKEN`
- `TWITTER_ACCESS_SECRET`

**LinkedIn**
- `LINKEDIN_ACCESS_TOKEN` (user or org token with `w_member_social` / `w_organization_social` scope)
- `LINKEDIN_MEMBER_URN` (like `urn:li:person:...`) or `LINKEDIN_ORG_URN` (like `urn:li:organization:...`)

> Note: You are responsible for complying with platform ToS and rate limits.

## Running the Action
- Manual: **Actions → Post Socials → Run workflow** and fill inputs.
- Scheduled: uncomment the `schedule:` cron block in the workflow and adjust times (UTC).

## CLI usage (local)
```bash
python automation/open_submission_pages.py --repo https://github.com/Creators/... \
  --deadline "2025-09-15" --prize "$20k"

python automation/generate_calendar.py outreach-kit/schedule.csv --outfile outreach_schedule.ics
```
