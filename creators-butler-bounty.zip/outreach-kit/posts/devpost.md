**Project Title:** Creators Butler – Sealed‑Kernel Autoupgrading Agent  
**Summary:** Build a Manager Kernel that enforces a signed policy, then designs/codes/tests/deploys its own Specialists. Local‑first, RAG+citations, audits, kill switch, hardware‑aware self‑upgrade.  
**Deliverables:** As per repo brief. **Efficiency scoring** included.  
**Prizes:** <PRIZE_TOTAL> • **Deadline:** <DEADLINE>  
**Repo/Starter Kit:** <REPO_URL>?utm_source=devpost&utm_medium=listing&utm_campaign=bounty_launch
