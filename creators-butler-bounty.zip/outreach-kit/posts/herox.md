Challenge: Sealed‑Kernel AI that codes its own tools (Local‑first).  
Overview, rules, scoring rubric (incl. Efficiency & Footprint) in repo: <REPO_URL>?utm_source=herox&utm_medium=listing&utm_campaign=bounty_launch  
Prizes: $10k • Deadline: January 01, 2026
