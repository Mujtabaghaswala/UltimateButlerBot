Show HN: Sealed‑Kernel AI that codes its own tools (bounty `<PRIZE_TOTAL>`, Docker starter kit)
One AI “Manager Kernel” that designs/tests/deploys its own Specialists under a signed policy. Local‑first, RAG+citations, audits, kill switch, and **self‑upgrade to new hardware**. Scored for safety, evals, ops, and tiny footprint.
Repo + starter kit: <REPO_URL>?utm_source=hn&utm_medium=post&utm_campaign=bounty_launch
Deadline: <DEADLINE>
