[Bounty] Build a sealed‑kernel, self‑upgrading agent (RAG+citations, audits, canary/rollback). Local‑first; no cloud required. Clear rubric incl. RAM/VRAM+disk budget scoring. Starter kit & tests: <REPO_URL>?utm_source=reddit_ml&utm_medium=post&utm_campaign=bounty_launch
Prizes: $10k • Deadline: January 01, 2026
(Mods: fits project/bounty rules; no scraping; synthetic data)
