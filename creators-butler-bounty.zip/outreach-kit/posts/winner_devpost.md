**Winner — Creators Butler Bounty ($10k):** <WINNER_TEAM> — “<WINNER_PROJECT>”
Details & rubric: <REPO_URL>
Winner repo/demo: <WINNER_REPO_URL>