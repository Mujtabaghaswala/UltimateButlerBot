[Bounty] Sealed‑kernel local agent that codes its own tools (Docker, RAG+citations, kill switch). Scored for safety and **small footprint**. Repo + starter kit: <REPO_URL>?utm_source=reddit_localllama&utm_medium=post&utm_campaign=bounty_launch
Prizes: $10k • Deadline: January 01, 2026
