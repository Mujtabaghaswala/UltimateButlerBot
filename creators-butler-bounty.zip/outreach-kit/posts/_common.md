**Title:** Sealed‑Kernel AI that codes its own tools (local‑first bounty, `<PRIZE_TOTAL>`, Docker starter kit)

**Body:**
Build a **Manager Kernel** that designs/tests/deploys its own Specialists under a signed policy. Local‑first, RAG+citations, audits, kill switch, and **self‑upgrade to new hardware**. Scored for safety, evals, ops, **and efficiency/footprint** (RAM+VRAM, disk, cold‑start).

• Starter repo + harness: <REPO_URL>
• Prizes: <PRIZE_TOTAL> • Deadline: <DEADLINE>
• No live trading, synthetic data only, permissive licenses.
