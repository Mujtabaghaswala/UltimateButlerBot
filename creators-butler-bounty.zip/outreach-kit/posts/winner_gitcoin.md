**WINNER:** Creators Butler Bounty ($10k) → <WINNER_TEAM> — “<WINNER_PROJECT>”
Brief & rubric: <REPO_URL>
Winner repo: <WINNER_REPO_URL>