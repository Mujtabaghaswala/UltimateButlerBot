**Bounty:** Creators Butler – sealed‑kernel self‑upgrading agent.  
**Repo/Starter Kit:** <REPO_URL>?utm_source=gitcoin&utm_medium=bounty&utm_campaign=bounty_launch  
**Payout:** <PRIZE_TOTAL> • **Deadline:** <DEADLINE>  
**Rules:** Permissive licenses; synthetic data; no live trading; pass harness tests; efficiency points for small footprint.
