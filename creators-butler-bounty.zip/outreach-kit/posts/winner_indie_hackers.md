Winner announced ($10k): <WINNER_TEAM> — “<WINNER_PROJECT>”
Repo: <WINNER_REPO_URL> • Brief/rubric: <REPO_URL>