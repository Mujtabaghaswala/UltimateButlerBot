[Winner] $10k Creators Butler Bounty → **<WINNER_TEAM>** for “<WINNER_PROJECT>”
Local‑first, sealed‑kernel agent that builds its own tools; tiny footprint; RAG+citations; kill switch; upgrades to new GPUs.
Winner repo: <WINNER_REPO_URL> — Brief: <REPO_URL>