Results: Creators Butler Bounty — Winner <WINNER_TEAM> (“<WINNER_PROJECT>”) — $10k
Brief: <REPO_URL> • Winner repo: <WINNER_REPO_URL>