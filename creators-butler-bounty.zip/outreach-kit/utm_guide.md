# UTM Guide

Append UTM parameters to your repo link to track which channel converts.

Example base:
```
<REPO_URL>
```

Channel tags:
- Hacker News: `?utm_source=hn&utm_medium=post&utm_campaign=bounty_launch`
- Reddit ML: `?utm_source=reddit_ml&utm_medium=post&utm_campaign=bounty_launch`
- Reddit LocalLLaMA: `?utm_source=reddit_localllama&utm_medium=post&utm_campaign=bounty_launch`
- Devpost: `?utm_source=devpost&utm_medium=listing&utm_campaign=bounty_launch`
- Gitcoin: `?utm_source=gitcoin&utm_medium=bounty&utm_campaign=bounty_launch`
- Discord: `?utm_source=discord&utm_medium=announce&utm_campaign=bounty_launch`
- Slack (MLOps): `?utm_source=mlops_slack&utm_medium=announce&utm_campaign=bounty_launch`
- LinkedIn: `?utm_source=linkedin&utm_medium=post&utm_campaign=bounty_launch`
- Twitter/X: `?utm_source=twitter&utm_medium=post&utm_campaign=bounty_launch`

For mid-challenge/last-call waves, change `utm_campaign` accordingly: `bounty_mid`, `bounty_lastcall`.
