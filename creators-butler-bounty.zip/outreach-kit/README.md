# Outreach Kit — Creators Butler Bounty

This folder contains **ready-to-post copy** for each platform plus a schedule template and UTM link guide.

- Replace tokens like `<REPO_URL>`, `<DEADLINE>`, `<PRIZE_TOTAL>`, `<LAUNCH_DATE>`.
- Keep posts mostly identical across channels for consistency, but **respect each forum’s rules** (especially Reddit weekly threads).
- Suggested posting window (America/Chicago): Tue–Thu, 9–11am CT for initial launch; mid-challenge update after 10–12 days; 48h-before-deadline reminder.

Files:
- `posts/*.md|.txt` – channel-specific copy
- `schedule.csv` – suggested cadence
- `utm_guide.md` – how to tag links for attribution
